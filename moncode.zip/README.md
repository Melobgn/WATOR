Projet WATOR en groupe
